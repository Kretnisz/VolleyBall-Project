export const firebaseConfig = {
    apiKey: "AIzaSyB6xkryLH390-I4S7uG4jzpOorC8dDEg7o",
    authDomain: "volleyball-1eaa3.firebaseapp.com",
    projectId: "volleyball-1eaa3",
    storageBucket: "volleyball-1eaa3.appspot.com",
    messagingSenderId: "791066586852",
    appId: "1:791066586852:web:c1fcb255eb8ef98cb906f1",
    measurementId: "G-N9R99Z95L4"
};