export interface Player {
    name: string;
    img: string;
    achievementNum: number;
    achievementName: string;
    color: string;
}