
export interface Team {
    position: number;
    name: string;
    points: number;
    numberOfMatches: number;
    wins: number;
    losses: number;
  }