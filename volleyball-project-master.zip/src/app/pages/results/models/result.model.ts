export interface Result {
    homeName: string;
    homeScore: number;
    awayName: string;
    awayScore: number;
    homeImage: string;
    awayImage: string;
    id?: string;
}